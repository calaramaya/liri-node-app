console.log('this is loaded');

exports.twitterKeys = {
  consumer_key: 'A9VzxNVLbvW3y6e7mcsvCGAf8',
  consumer_secret: 'm6p7IAQe1r2axqaifx5GYMPg2qgqSWDWhDjzsYD9f0TdBjNARh',
  access_token_key: '3056767674-YGog1l4xWFRVCOWLZMsN7756kMzQe0iZ0Nl7RX2',
  access_token_secret: 'klmwqLKDbVLWTDRxS4LSJNCXzGNELoJAWlUPmienUrt6V'
}

exports.spotifyKeys = {
	id: "2f913e452d774543be6753cc794775b1",
  secret: "6883a6a5a52b467288e0d876bf6f1660"
}